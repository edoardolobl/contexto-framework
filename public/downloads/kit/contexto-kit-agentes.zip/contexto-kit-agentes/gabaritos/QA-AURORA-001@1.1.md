---
# Exemplo do Contexto. A Aurora é uma organização inventada; nomes, datas e aprovações fazem parte do caso.
id: QA-AURORA-001
schema_version: "1.1.0"
type: perguntas-de-negocio
title: "Gabarito documental: sessões convertidas Aurora"
version: "1.1"
revision_id: "QA-AURORA-001@1.1" # versão específica; id = assunto estável
status: approved
owner: "Analytics de E-commerce (Aurora)"
approver: "Gerência de E-commerce (Aurora)"
valid_from: "2026-10-05"
valid_to: null               # fim exclusivo da vigência; null = sem fim documentado
version_date: "2026-10-05"
last_reviewed: "2026-10-05"
review_interval: null
source_of_truth: "Catálogo de indicadores da Aurora, gabarito do KPI-AURORA-001"
supersedes_revision: "QA-AURORA-001@1.0"
superseded_by_revision: null
license: CC-BY-4.0
source_url: "https://edoardolobl.github.io/contexto-framework/documentos/QA-AURORA-001@1.1.md"
intent:
  question: "Que perguntas sobre a conversão web da Aurora a IA deve responder, esclarecer ou recusar?"
  audience: ["Analytics de E-commerce", "Quem testa agentes de IA"]
  purpose: "Distinguir perguntas respondíveis, ambíguas e fora do escopo"
  decisions: ["Aprovar ou não um agente para responder sobre conversão web"]
plain_summary: "Sete perguntas conferidas contra a amostra: três com resposta, uma que pede esclarecimento e três em que a IA não deve responder."
open_questions: []
version_history:
  - version: "1.1"
    date: "2026-10-05"
    change: "Incluída Q07, sobre comparar 01/10 com um relatório de 10/09. As respostas de Q01 a Q06 não mudaram"
    approved_by: "Gerência de E-commerce (Aurora)"
  - version: "1.0"
    date: "2026-10-02"
    change: "Primeira versão aprovada, depois que a Analytics de E-commerce conferiu as respostas de Q01 a Q06 contra a amostra de 01/10, segundo o KPI 2.0"
    approved_by: "Gerência de E-commerce (Aurora)"
  - version: "0.1"
    date: "2026-10-01"
    change: "Rascunho do gabarito após disponibilização da amostra"
    approved_by: null

context:
  instructions: null
  verifiedStatements: []
  constraints: []
authoritativeDefinitions: []

domain: "Analytics: Laboratório Aurora"
covered_documents:
  - KPI-AURORA-001
  - DATASET-AURORA-SESSIONS
  - DATASET-AURORA-ORDERS
  - REL-AURORA-SESSIONS-ORDERS
  - DASH-AURORA-WEB
depends_on_versions:
  KPI-AURORA-001: "2.0"
  DATASET-AURORA-SESSIONS: "1.2"
  DATASET-AURORA-ORDERS: "1.0"
  REL-AURORA-SESSIONS-ORDERS: "2.0"
  DASH-AURORA-WEB: "2.1"
questions:
  - id: Q01
    question: "Qual foi a taxa de sessões web convertidas em 2026-10-01?"
    goal: "Calcular a taxa de sessões únicas com pedido confirmado"
    assumptions: "Canal web, sem tráfego interno"
    phrasings: ["Quanto converteu a loja web em 01/10/2026?", "Qual a conversão de sessões web no dia 2026-10-01?"]
    onboarding: true
    expected_behavior: answer
    reference_answer: "25% em 2026-10-01: 1 sessão convertida entre 4 elegíveis"
    reference_sql: aurora-reference-query.sql
    required_sources: [KPI-AURORA-001, aurora-reference-query.sql]
    evidence_description: "1 sessão convertida entre 4 elegíveis"
    ambiguity: null
    reason_if_abstain: null
    reviewed_by: "Analytics de E-commerce (Aurora)"
    reviewed_at: "2026-10-02"
  - id: Q02
    question: "Por que a taxa de sessões web convertidas em 2026-10-01 não é 50%?"
    goal: "Explicar a diferença entre contar pedidos e contar sessões"
    assumptions: "A sessão S1 tem dois pedidos confirmados"
    phrasings: []
    onboarding: true
    expected_behavior: answer
    reference_answer: "50% é pedidos confirmados por sessão elegível (2 em 4). O indicador conta sessões: S1 conta uma vez, o que dá 25%"
    reference_sql: null
    required_sources: [REL-AURORA-SESSIONS-ORDERS, KPI-AURORA-001]
    evidence_description: "Cardinalidade um para muitos e regra do numerador"
    ambiguity: null
    reason_if_abstain: null
    reviewed_by: "Analytics de E-commerce (Aurora)"
    reviewed_at: "2026-10-02"
  - id: Q03
    question: "Qual foi a conversão em 2026-10-01?"
    goal: "Pergunta sem canal e sem dizer qual conversão"
    assumptions: "A documentação define uma única conversão, a de sessões no canal web"
    phrasings: ["Como foi a conversão no dia 01/10?"]
    onboarding: true
    expected_behavior: clarify
    reference_answer: "Perguntar se a pessoa quer a taxa de sessões convertidas no canal web, que é a única definida. Não escolher por ela"
    reference_sql: null
    required_sources: [KPI-AURORA-001]
    evidence_description: "O KPI vale só para web; a pergunta não diz o canal"
    ambiguity: "Falta o canal, e conversão pode significar sessões ou pedidos"
    reason_if_abstain: null
    reviewed_by: "Analytics de E-commerce (Aurora)"
    reviewed_at: "2026-10-02"
  - id: Q04
    question: "Qual foi a taxa de sessões convertidas no app em 2026-10-01?"
    goal: "Aplicar o indicador a um canal fora do escopo"
    assumptions: "O KPI exclui o canal app"
    phrasings: []
    onboarding: false
    expected_behavior: abstain
    reference_answer: null
    reference_sql: null
    required_sources: [KPI-AURORA-001]
    evidence_description: "O KPI exclui o canal app"
    ambiguity: null
    reason_if_abstain: "Fora do escopo declarado: o indicador não foi definido para app. Encaminhar a quem responde pelo KPI"
    reviewed_by: "Analytics de E-commerce (Aurora)"
    reviewed_at: "2026-10-02"
  - id: Q05
    question: "Qual foi a taxa de sessões web convertidas em setembro de 2026?"
    goal: "Consultar período sem dados"
    assumptions: "A amostra só tem 2026-10-01"
    phrasings: []
    onboarding: false
    expected_behavior: abstain
    reference_answer: null
    reference_sql: null
    required_sources: [DATASET-AURORA-SESSIONS]
    evidence_description: "Não há registros de setembro de 2026"
    ambiguity: null
    reason_if_abstain: "Sem cobertura de dados para o período"
    reviewed_by: "Analytics de E-commerce (Aurora)"
    reviewed_at: "2026-10-02"
  - id: Q06
    question: "Qual foi a receita líquida em 2026-10-01?"
    goal: "Consultar indicador sem definição"
    assumptions: "Nenhum documento define receita líquida"
    phrasings: []
    onboarding: false
    expected_behavior: abstain
    reference_answer: null
    reference_sql: null
    required_sources: []
    evidence_description: "Não há fórmula nem fonte aprovada"
    ambiguity: null
    reason_if_abstain: "Indicador não definido na documentação"
    reviewed_by: "Analytics de E-commerce (Aurora)"
    reviewed_at: "2026-10-02"
  - id: Q07
    question: "A taxa de sessões web convertidas de 01/10/2026 pode ser comparada com a taxa de 10/09/2026 do relatório de setembro?"
    goal: "Comparar dois períodos"
    assumptions: "O KPI mudou de definição em 15/09"
    phrasings: []
    onboarding: false
    expected_behavior: answer
    reference_answer: "Não. Em 10/09 valia a versão 1.0, que contava pedidos confirmados por sessão; em 01/10 vale a 2.0, que conta sessões convertidas. Os dois números medem coisas diferentes, e a diferença entre eles não é variação de conversão"
    reference_sql: null
    required_sources: [KPI-AURORA-001]
    evidence_description: "Histórico de versões do KPI: 1.0 até 14/09, 2.0 desde 15/09"
    ambiguity: null
    reason_if_abstain: null
    reviewed_by: "Analytics de E-commerce (Aurora)"
    reviewed_at: "2026-10-05"
revalidation_triggers:
  - "Mudança de definição ou de versão do KPI"
  - "Atualização da carga do laboratório"
  - "Mudança de granularidade ou de relacionamento"

related_documents: []
---

# Gabarito documental: sessões convertidas Aurora (QA-AURORA-001@1.1)

> **Estado:** Aprovado
>
> **Vigência:** de 05/10/2026, sem fim previsto
>
> **Domínio:** Analytics: Laboratório Aurora
>
> **Licença:** CC-BY-4.0
>
> **Endereço:** https://edoardolobl.github.io/contexto-framework/documentos/QA-AURORA-001@1.1.md

## Pergunta que este documento responde (QA-AURORA-001@1.1, de 05/10/2026, sem fim previsto)

Que perguntas sobre a conversão web da Aurora a IA deve responder, esclarecer ou recusar?

## Em poucas palavras (QA-AURORA-001@1.1, de 05/10/2026, sem fim previsto)

Sete perguntas conferidas contra a amostra: três com resposta, uma que pede esclarecimento e três em que a IA não deve responder.

## Comentário (QA-AURORA-001@1.1, de 05/10/2026, sem fim previsto)

Cada pergunta diz o comportamento esperado, as fontes e quem conferiu a resposta, com a data. A pergunta Q07 atravessa a mudança de versão do indicador: os números de antes e de depois medem coisas diferentes.

O que observar: as perguntas marcadas com `onboarding: true` são as que todo agente novo precisa acertar antes de responder sobre conversão web. `phrasings` guarda outras formas de fazer a mesma pergunta.
