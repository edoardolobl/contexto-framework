---
# Exemplo do Contexto. A Aurora é uma organização inventada; nomes, datas e aprovações fazem parte do caso.
id: QA-AURORA-002
schema_version: "1.1.0"
type: perguntas-de-negocio
title: "Gabarito documental: quais eventos pararam de coletar"
version: "1.0"
revision_id: "QA-AURORA-002@1.0" # versão específica; id = assunto estável
status: approved
owner: "Analytics de E-commerce (Aurora)"
approver: "Gerência de Analytics (Aurora)"
valid_from: "2026-11-17"
valid_to: null               # fim exclusivo da vigência; null = sem fim documentado
version_date: "2026-11-17"
last_reviewed: "2026-11-17"
review_interval: null
source_of_truth: "Plano de mensuração da Aurora, gabarito da regra de evento quebrado"
supersedes_revision: null
superseded_by_revision: null
license: CC-BY-4.0
source_url: "https://edoardolobl.github.io/contexto-framework/documentos/QA-AURORA-002@1.0.md"
intent:
  question: "Que perguntas sobre os eventos de coleta da Aurora a IA deve responder, esclarecer ou recusar?"
  audience: ["Analytics de E-commerce", "Quem testa agentes de IA"]
  purpose: "Distinguir um evento que parou de coletar de um evento raro com dias em zero"
  decisions: ["Abrir ou não um chamado de Engenharia de Tagueamento para um evento"]
plain_summary: "Seis perguntas conferidas contra a amostra do Laboratório Aurora 2: três com resposta, uma que pede esclarecimento e duas em que a IA não deve responder."
open_questions: []
version_history:
  - version: "1.0"
    date: "2026-11-17"
    change: "Primeira versão aprovada, depois que a Analytics de E-commerce conferiu as seis respostas contra a amostra de 16/11, pela regra de evento quebrado 1.1"
    approved_by: "Gerência de Analytics (Aurora)"
  - version: "0.1"
    date: "2026-11-16"
    change: "Rascunho do gabarito após disponibilização da amostra"
    approved_by: null

context:
  instructions: null
  verifiedStatements: []
  constraints: []
authoritativeDefinitions: []

domain: "Analytics: Laboratório Aurora 2"
covered_documents:
  - EVENT-AURORA-GENERATE-LEAD
  - DECISION-AURORA-EVENTO-QUEBRADO
depends_on_versions:
  EVENT-AURORA-GENERATE-LEAD: "1.1"
  DECISION-AURORA-EVENTO-QUEBRADO: "1.1"
questions:
  - id: Q01
    question: "Quais eventos do plano de mensuração pararam de coletar, considerando os dias completos até 15/11/2026?"
    goal: "Separar o evento que parou de coletar dos eventos que só têm dias em zero"
    assumptions: "Consulta em 17/11/2026; só valem dias completos (D+2), então o último dia contado é 15/11"
    phrasings: ["Algum evento do plano parou?", "O que está sem coletar desde a semana passada?"]
    onboarding: true
    expected_behavior: answer
    reference_answer: "Só o add_to_cart no México, sem nenhuma linha desde 11/11 (5 dias completos seguidos em zero, com média de 30 por dia na janela). O generate_lead no Brasil está em zero há 2 dias, o que é normal: tem zero em 9 de 27 dias completos e tolerância de 4 dias. O generate_lead não existe no México, então não se avalia lá"
    reference_sql: aurora-lab2-reference-query.sql
    required_sources: [DECISION-AURORA-EVENTO-QUEBRADO, EVENT-AURORA-GENERATE-LEAD, aurora-lab2-reference-query.sql]
    evidence_description: "Consulta de referência: add_to_cart MX com 5 dias em zero; generate_lead BR com sequência atual de 2 dias"
    ambiguity: null
    reason_if_abstain: null
    reviewed_by: "Analytics de E-commerce (Aurora)"
    reviewed_at: "2026-11-17"
  - id: Q02
    question: "O generate_lead parou no Brasil?"
    goal: "Saber se zero disparos recentes de um evento raro indicam quebra"
    assumptions: "Operação Brasil, dias completos até 15/11/2026"
    phrasings: ["O generate_lead da BR está quebrado?"]
    onboarding: true
    expected_behavior: answer
    reference_answer: "Não. Em 14 e 15/11 ele ficou em zero, mas tem zero em 9 de 27 dias completos, a maior sequência histórica em zero foi de 3 dias (27 a 29/10) e a tolerância é de 4 dias. Sem linha de 16/11, porque esse dia ainda está incompleto"
    reference_sql: aurora-lab2-reference-query.sql
    required_sources: [EVENT-AURORA-GENERATE-LEAD, DECISION-AURORA-EVENTO-QUEBRADO]
    evidence_description: "Sequência atual de 2 dias, abaixo da tolerância de 4"
    ambiguity: null
    reason_if_abstain: null
    reviewed_by: "Analytics de E-commerce (Aurora)"
    reviewed_at: "2026-11-17"
  - id: Q03
    question: "O generate_lead está quebrado?"
    goal: "Pergunta sem operação, para um evento que só existe numa"
    assumptions: "O evento existe só no Brasil; no México não está ativo"
    phrasings: []
    onboarding: true
    expected_behavior: clarify
    reference_answer: "Perguntar de qual operação a pessoa fala. O evento só está ativo no Brasil; no México não dispara, e isso não é quebra"
    reference_sql: null
    required_sources: [EVENT-AURORA-GENERATE-LEAD]
    evidence_description: "O plano lista o generate_lead por operação, e só a BR está ativa"
    ambiguity: "Falta a operação: o resultado muda entre Brasil e México"
    reason_if_abstain: null
    reviewed_by: "Analytics de E-commerce (Aurora)"
    reviewed_at: "2026-11-17"
  - id: Q04
    question: "Quantas compras o México teve em 16/11/2026?"
    goal: "Consultar um dia que ainda não fechou"
    assumptions: "A carga de 16/11 está incompleta; só vale a partir de D+2"
    phrasings: []
    onboarding: false
    expected_behavior: abstain
    reference_answer: null
    reference_sql: null
    required_sources: [DECISION-AURORA-EVENTO-QUEBRADO]
    evidence_description: "A carga de 16/11 está marcada como incompleta nas duas operações"
    ambiguity: null
    reason_if_abstain: "Dia incompleto até D+2: o número de 16/11 é parcial e não pode ser lido como queda. Responder só com dias completos, até 15/11"
    reviewed_by: "Analytics de E-commerce (Aurora)"
    reviewed_at: "2026-11-17"
  - id: Q05
    question: "Qual a taxa de add_to_cart para purchase no México?"
    goal: "Calcular um indicador que ninguém definiu"
    assumptions: "Não há indicador aprovado de taxa entre os dois eventos"
    phrasings: []
    onboarding: true
    expected_behavior: abstain
    reference_answer: null
    reference_sql: null
    required_sources: []
    evidence_description: "Não há KPI nem fórmula aprovada para essa taxa"
    ambiguity: null
    reason_if_abstain: "Sem indicador aprovado: não calcular com a definição de mercado nem com a de outra operação. Perguntar a quem responde pelo indicador"
    reviewed_by: "Analytics de E-commerce (Aurora)"
    reviewed_at: "2026-11-17"
  - id: Q06
    question: "Qual foi a receita de purchase no Brasil em 02/11/2026?"
    goal: "Somar a receita dos pedidos sem duplicar depois da junção com os itens"
    assumptions: "A receita mora no pedido; juntar com os itens repete o pedido uma vez por item"
    phrasings: ["Quanto a BR vendeu em 02/11?"]
    onboarding: true
    expected_behavior: answer
    reference_answer: "R$ 500, somando os 3 pedidos (R$ 120, R$ 80 e R$ 300) na tabela de pedidos. Somar depois de juntar com os itens dá R$ 1.100, valor errado: o pedido de R$ 300 tem 3 itens e entra 3 vezes"
    reference_sql: null
    required_sources: [aurora-lab2-fixture.sql]
    evidence_description: "Soma na tabela de pedidos: R$ 500; soma depois da junção com os itens: R$ 1.100"
    ambiguity: null
    reason_if_abstain: null
    reviewed_by: "Analytics de E-commerce (Aurora)"
    reviewed_at: "2026-11-17"
revalidation_triggers:
  - "Mudança de versão da regra de evento quebrado ou do evento"
  - "Atualização da carga do laboratório"
  - "Mudança do plano de mensuração"

related_documents: []
---

# Gabarito documental: quais eventos pararam de coletar (QA-AURORA-002@1.0)

> **Estado:** Aprovado
>
> **Vigência:** de 17/11/2026, sem fim previsto
>
> **Domínio:** Analytics: Laboratório Aurora 2
>
> **Licença:** CC-BY-4.0
>
> **Endereço:** https://edoardolobl.github.io/contexto-framework/documentos/QA-AURORA-002@1.0.md

## Pergunta que este documento responde (QA-AURORA-002@1.0, de 17/11/2026, sem fim previsto)

Que perguntas sobre os eventos de coleta da Aurora a IA deve responder, esclarecer ou recusar?

## Em poucas palavras (QA-AURORA-002@1.0, de 17/11/2026, sem fim previsto)

Seis perguntas conferidas contra a amostra do Laboratório Aurora 2: três com resposta, uma que pede esclarecimento e duas em que a IA não deve responder.

## Comentário (QA-AURORA-002@1.0, de 17/11/2026, sem fim previsto)

Cada pergunta diz o comportamento esperado, as fontes e quem conferiu a resposta, com a data. Q01 é a pergunta do caso: o agente só acerta se olhar o histórico por operação.

O que observar: as perguntas marcadas com `onboarding: true` são as que todo agente novo precisa acertar antes de responder sobre eventos de coleta.
